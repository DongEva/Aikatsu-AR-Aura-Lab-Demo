"""Reproducible synthetic QA. No physical webcam or live ML accuracy claims.
Run: python tests/browser_smoke.py (requires Playwright and Chromium).
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, shutil, math
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text().replace("if(new URLSearchParams(location.search).has('test'))","if(true)")
checks=[];errors=[]
def check(name,value,detail=None):
 row={'test':name,'passed':bool(value)}
 if detail is not None:row['detail']=detail
 checks.append(row);print(('PASS ' if value else 'FAIL ')+name,flush=True)
def snapshot(p,name):
 p.locator('#toast').evaluate("e=>e.classList.remove('show')")
 p.screenshot(path=str(ROOT/'screenshots'/name),full_page=True)
def slider(p,id,v):p.locator('#'+id).evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event("input"));}',str(v))
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('google-chrome'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 p=b.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1,accept_downloads=True)
 req=[];p.on('request',lambda r:req.append(r.url));p.on('pageerror',lambda e:errors.append(str(e)))
 p.set_content(HTML,wait_until='load');p.wait_for_function('!!window.__AURA_TEST__');p.wait_for_timeout(450)
 check('Offline demo initializes without network',not req,req)
 check('Five original themes preserved',p.locator('.theme').count()==5)
 check('Default ground mode is fixed and calibrated in demo',p.evaluate("__AURA_TEST__.spatial.floorMode==='fixed' && !!__AURA_TEST__.spatial.lock"))
 for theme in ['rose','moon','gothic','bow','rainbow']:
  p.locator('[data-theme="'+theme+'"]').click();p.wait_for_timeout(120)
  check('Theme '+theme,p.evaluate("__AURA_TEST__.state.theme") == theme and p.locator('.theme[aria-pressed="true"]').count()==1)
 # The ground snapshot does not use torso center, yaw, tilt, aura size or height.
 independent=p.evaluate('''()=>{const a=__AURA_TEST__,g=JSON.stringify(a.groundPose());a.rig.x+=75;a.rig.y-=25;a.rig.yaw=1.2;a.rig.tilt=.2;a.rig.unit*=1.15;a.state.size=1.4;a.state.height=.6;const same=g===JSON.stringify(a.groundPose());return same;}''')
 check('Fixed ground independent of torso position, rotation, scale and aura settings',independent)
 p.locator('#resetBtn').click();p.wait_for_timeout(150)
 g=p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)')
 r=p.locator('#stage').bounding_box();before=p.evaluate('__AURA_TEST__.target.x')
 p.mouse.move(r['x']+r['width']*.48,r['y']+r['height']*.42);p.mouse.down();p.mouse.move(r['x']+r['width']*.62,r['y']+r['height']*.43,steps=3);p.mouse.up();p.wait_for_timeout(200)
 check('Demo drag moves body, not fixed floor',p.evaluate('__AURA_TEST__.target.x')>before and p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)')==g)
 p.locator('#calibrateBtn').click()
 check('Recalibrate explicitly moves ground',p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)')!=g)
 # Pure project-matrix checks use actual implementation.
 geometry=p.evaluate('''()=>{const a=__AURA_TEST__,old={...a.rig};a.spatial.followYaw=true;a.rig.tilt=0;a.rig.pitch=0;a.state.height=0;a.state.size=1;const points=Array.from({length:180},(_,i)=>({x:2.04*Math.cos(i/180*2*Math.PI),y:0,z:2.04*Math.sin(i/180*2*Math.PI)}));let widths=[];let qs=[];for(const yaw of [0,Math.PI/2,Math.PI]){a.rig.yaw=yaw;let proj=points.map(p=>a.project(p));widths.push(Math.max(...proj.map(p=>p.x))-Math.min(...proj.map(p=>p.x)));qs.push(a.project({x:0,y:.09,z:2.08}));}Object.assign(a.rig,old);return{widths,depths:qs.map(q=>q.z),sideX:qs[1].x-qs[0].x};}''')
 check('Horizontal circle does not collapse at 90-degree body yaw',max(geometry['widths'])/min(geometry['widths'])<1.02,geometry)
 check('Front charm crosses to the rear after 180-degree turn',geometry['depths'][0]>1 and geometry['depths'][2]<-1)
 check('Front charm moves around torso at 90 degrees',abs(geometry['sideX'])>20)
 p.locator('#resetBtn').click();p.locator('[data-theme="gothic"]').click();slider(p,'speed',0);slider(p,'yaw',0);p.wait_for_timeout(400)
 snapshot(p,'gothic-front.png');slider(p,'yaw',90);p.wait_for_timeout(600);snapshot(p,'gothic-side.png')
 check('Manual yaw control rotates actual rig',abs(p.evaluate('__AURA_TEST__.rig.yaw')-math.pi/2)<.04)
 p.locator('#turnDemo').click();old=p.evaluate('__AURA_TEST__.spatial.demoYaw');p.wait_for_timeout(230)
 check('Turn demonstration animates independently from ornamental drift speed',p.evaluate('__AURA_TEST__.spatial.demoYaw')>old)
 p.locator('#turnDemo').click()
 # Occlusion of a solid test silhouette is pixel-verifiable, not just state.
 pix=p.evaluate('''()=>{const a=__AURA_TEST__;a.spatial.autoTurn=false;a.spatial.demoYaw=0;a.rig.yaw=0;a.state.mode='camera';a.state.tracking='auto';a.state.hasMask=true;a.state.maskTime=performance.now();a.spatial.maskFrameId=7;a.spatial.poseFrameId=7;a.rig.presence=1;const m=a.maskCanvas.getContext('2d');m.fillStyle='white';m.fillRect(0,0,a.maskCanvas.width,a.maskCanvas.height);a.state.occlusion=true;a.drawAura();const sum=c=>{let d=c.getContext('2d').getImageData(0,0,c.width,c.height).data,s=0;for(let i=3;i<d.length;i+=4)s+=d[i];return s;};const on={rear:sum(a.rear),front:sum(a.front)};a.state.occlusion=false;a.drawAura();const off={rear:sum(a.rear),front:sum(a.front)};a.state.mode='demo';a.state.occlusion=true;a.state.hasMask=false;a.resetGround({demo:true});return{on,off};}''')
 check('Person mask removes rear effects but preserves foreground effects',pix['on']['rear']==0 and pix['on']['front']>10000 and pix['off']['rear']>10000,pix)
 # A mask from a different input frame must never be applied to a newer frame.
 stale=p.evaluate('''()=>{const a=__AURA_TEST__;a.state.mode='camera';a.state.tracking='auto';a.state.hasMask=true;a.state.maskTime=performance.now();a.spatial.maskFrameId=1;a.spatial.poseFrameId=2;a.rig.presence=1;a.drawAura();let d=a.rear.getContext('2d').getImageData(0,0,a.rear.width,a.rear.height).data,s=0;for(let i=3;i<d.length;i+=4)s+=d[i];a.state.mode='demo';a.state.hasMask=false;a.resetGround({demo:true});return s;}''')
 check('Mismatched frame mask safely suppresses the rear pass',stale==0)
 # Synthetic camera stream tests permission/lifecycle and pose ingest without ML.
 p.evaluate('''()=>{const cv=document.createElement('canvas');cv.width=1280;cv.height=720;const g=cv.getContext('2d');let k=0;window.__feedTimer=setInterval(()=>{g.fillStyle='#201c29';g.fillRect(0,0,1280,720);g.fillStyle='#776080';g.fillRect(565+(k++%8),50,150,620);},45);window.__feed=cv.captureStream(20);window.__calls=0;Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async opts=>{window.__opts=opts;window.__calls++;return __feed;}}});}''')
 p.locator('#manualBtn').click();p.locator('#cameraBtn').click();p.wait_for_function("__AURA_TEST__.state.mode==='camera'",timeout=5000)
 check('Manual camera starts without model downloads',p.evaluate("__AURA_TEST__.state.mode==='camera' && __AURA_TEST__.state.tracking==='manual'"))
 check('No audio or microphone requested',p.evaluate('__opts.audio===false'))
 # Canonical world-landmark synthetic person: left shoulder appears on camera right.
 p.evaluate('''()=>{window.makePose=(deg=0,dx=0,feet=true)=>{const a=deg*Math.PI/180,lm=Array.from({length:33},()=>({x:.5,y:.5,z:0,visibility:0})),wl=Array.from({length:33},()=>({x:0,y:0,z:0,visibility:0}));for(const [i,x,y,z]of[[11,.20,-.5,0],[12,-.20,-.5,0],[23,.13,0,0],[24,-.13,0,0],[27,.10,.76,0],[28,-.10,.76,0],[29,.10,.83,0],[30,-.10,.83,0],[31,.10,.84,-.05],[32,-.10,.84,-.05]]){const xx=x*Math.cos(a)+z*Math.sin(a),zz=x*Math.sin(a)+z*Math.cos(a);wl[i]={x:xx,y,z:zz,visibility:.99};lm[i]={x:.5+dx+xx*.42,y:.52+y*.4,z:zz*.42,visibility:feet||i<27?.99:0};}const data=new Float32Array(32*32);for(let y=0;y<32;y++)for(let x=0;x<32;x++)data[y*32+x]=(x>12&&x<19&&y>1&&y<30)?1:0;return{landmarks:[lm],worldLandmarks:[wl],segmentationMasks:[{width:32,height:32,getAsFloat32Array:()=>data}]};};window.__angle=0;window.__dx=0;window.__feet=true;const a=__AURA_TEST__;a.state.tracking='auto';a.resetGround();window.__poseTimer=setInterval(()=>a.acceptResult(makePose(__angle,__dx,__feet),performance.now()),55);}''')
 p.wait_for_timeout(1250)
 check('Stable sole landmarks calibrate and lock the floor',p.evaluate('!!__AURA_TEST__.spatial.lock && !__AURA_TEST__.spatial.calibrating'))
 check('Auto pose supplies mask and body center',p.evaluate('__AURA_TEST__.state.hasPose && __AURA_TEST__.state.hasMask'))
 anchor=p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)');baseunit=p.evaluate('__AURA_TEST__.target.unit');x=p.evaluate('__AURA_TEST__.target.x')
 p.evaluate('__dx=.08');p.wait_for_timeout(190)
 check('Camera body translation follows landmarks without moving floor',p.evaluate('__AURA_TEST__.target.x')!=x and p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)')==anchor)
 for angle in [30,60,90,120,150,180]:
  p.evaluate(f'__angle={angle}');p.wait_for_timeout(110)
 p.wait_for_timeout(200)
 check('3D shoulder and hip landmarks drive signed back-view yaw',abs(abs(p.evaluate('__AURA_TEST__.rig.yaw'))-math.pi)<.15,p.evaluate('__AURA_TEST__.rig.yaw'))
 p.evaluate('__angle=90');p.wait_for_timeout(250)
 unit=p.evaluate('__AURA_TEST__.target.unit')
 check('Side view does not collapse aura scale with apparent shoulder width',.80<unit/baseunit<1.20,{'front':baseunit,'side':unit})
 p.evaluate('__feet=false');p.wait_for_timeout(180)
 check('Already calibrated floor persists in half-body framing',p.evaluate('!!__AURA_TEST__.groundPose() && !__AURA_TEST__.spatial.feetVisible') and p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)')==anchor)
 # Ground lock is stored in raw video coordinates, consistent with mirror + crop.
 mirror=p.evaluate('''()=>{const a=__AURA_TEST__,w=a.getView().W,p=a.groundPose();a.state.mirror=!a.state.mirror;const q=a.groundPose();a.state.mirror=!a.state.mirror;return Math.abs(p.x+q.x-w)<.01 && Math.abs(p.y-q.y)<.01;}''')
 check('Ground calibration uses same mirror transform as video',mirror)
 p.evaluate('clearInterval(__poseTimer)');p.wait_for_timeout(650)
 check('Lost person fades aura without deleting calibrated ground',p.evaluate('__AURA_TEST__.target.presence===0 && !__AURA_TEST__.state.hasMask && !!__AURA_TEST__.groundPose()'))
 floor_visible=p.evaluate('''()=>{const c=__AURA_TEST__.groundLayer,d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let sum=0;for(let i=3;i<d.length;i+=4)sum+=d[i];return sum>1000;}''')
 check('Calibrated floor remains visibly rendered after pose loss',floor_visible)
 for t in ['rose','moon','bow','rainbow','gothic']:p.locator('[data-theme="'+t+'"]').click()
 check('Switching themes preserves camera stream and ground calibration',p.evaluate('__calls===1 && __feed.getTracks()[0].readyState==="live"') and p.evaluate('JSON.stringify(__AURA_TEST__.spatial.lock)')==anchor)
 p.locator('#cameraBtn').click();p.evaluate('clearInterval(__feedTimer)')
 check('Stopping camera stops all media tracks',p.evaluate('__feed.getTracks().every(t=>t.readyState==="ended") && __AURA_TEST__.state.mode==="demo"'))
 # Snapshot and controls regression.
 with p.expect_download() as got:p.locator('#snapshotBtn').click()
 got.value.save_as(str(ROOT/'tests'/'snapshot.png'))
 check('PNG capture remains available',(ROOT/'tests'/'snapshot.png').read_bytes().startswith(b'\x89PNG'))
 p.locator('#helpBtn').click();check('Help dialog documents calibration limitation',p.locator('#help').evaluate('e=>e.open') and 'SLAM' in p.locator('#help').inner_text());p.locator('#closeHelp').click()
 p.locator('#projectionBtn').click();check('Black projection retains mode',p.evaluate('__AURA_TEST__.spatial.projectionOnly && __AURA_TEST__.state.mode==="demo"'));p.locator('#projectionBtn').click()
 p.locator('#resetBtn').click();p.wait_for_timeout(160)
 delta_before=p.evaluate('''()=>{const a=__AURA_TEST__,g=a.groundPose();return[(g.x-a.rig.x)/a.rig.unit,(g.y-a.rig.y)/a.rig.unit];}''')
 p.set_viewport_size({'width':390,'height':844});p.wait_for_timeout(200)
 delta_after=p.evaluate('''()=>{const a=__AURA_TEST__,g=a.groundPose();return[(g.x-a.rig.x)/a.rig.unit,(g.y-a.rig.y)/a.rig.unit];}''')
 check('Viewport resize preserves demo body-to-floor relationship',max(abs(a-b) for a,b in zip(delta_before,delta_after))<.02,{'before':delta_before,'after':delta_after})
 p.evaluate('__AURA_TEST__.resize()');p.wait_for_timeout(160)
 actor_visible=p.evaluate('''()=>{const c=__AURA_TEST__.actorLayer,d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let sum=0;for(let i=3;i<d.length;i+=4)sum+=d[i];return sum>1000;}''')
 check('Repeated resize does not clear cached mannequin permanently',actor_visible)
 for w,h in [(1440,1050),(1024,768),(768,1024),(390,844),(320,740)]:
  p.set_viewport_size({'width':w,'height':h});p.wait_for_timeout(150)
  check('Responsive page has no horizontal overflow '+str(w),p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  if w==390:
   p.locator('[data-theme="rainbow"]').click();p.wait_for_timeout(250);snapshot(p,'mobile-rainbow.png')
 p.set_viewport_size({'width':1440,'height':1050});p.locator('[data-theme="rainbow"]').click();slider(p,'yaw',32);p.wait_for_timeout(400);snapshot(p,'rainbow-spatial.png')
 check('No uncaught JavaScript errors',not errors,errors)
 b.close()
report={'passed':sum(c['passed'] for c in checks),'total':len(checks),'environment':'Chromium headless with actual release HTML injected into about:blank; this environment blocks localhost navigation. Camera stream, landmarks and masks are synthetic. Not a physical webcam test or MediaPipe model accuracy test.','checks':checks,'errors':errors}
(ROOT/'tests'/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('RESULT',report['passed'],'/',report['total'])
raise SystemExit(0 if report['passed']==report['total'] else 1)
