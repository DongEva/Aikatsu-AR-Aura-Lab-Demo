#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  python3 start.py
elif command -v node >/dev/null 2>&1; then
  node start.mjs
else
  printf '\n没有找到 Python 3 或 Node.js。\n你仍然可以双击 index.html，先使用演示模式。\n自动人体跟踪建议通过本地服务器运行。\n'
fi
printf '\n按回车关闭窗口。'
read -r _
