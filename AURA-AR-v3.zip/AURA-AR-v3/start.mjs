// Optional Node.js launcher; no npm install required.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { dirname, resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
const root=dirname(fileURLToPath(import.meta.url));
const types={'.html':'text/html; charset=utf-8','.mjs':'text/javascript','.js':'text/javascript','.wasm':'application/wasm','.task':'application/octet-stream','.json':'application/json','.png':'image/png','.md':'text/plain; charset=utf-8'};
const server=http.createServer(async(req,res)=>{
 try {
  const rel=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  const path=resolve(root,'.'+(rel==='/'?'/index.html':rel));
  if(path!==root&&!path.startsWith(root+sep)){res.writeHead(403);res.end();return;}
  const data=await readFile(path);
  res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Permissions-Policy':'camera=(self), microphone=()'});
  res.end(req.method==='HEAD'?undefined:data);
 }catch{res.writeHead(404,{'Content-Type':'text/plain'});res.end('Not found');}
});
let port=8765;
server.on('error',e=>{if(e.code==='EADDRINUSE'&&port<8785){server.listen(++port,'127.0.0.1');}else{console.error(e);process.exit(1);}});
server.on('listening',()=>{
 const url=`http://127.0.0.1:${port}/`;
 console.log(`\nAURA / 偶像气场\n${url}\n保持此窗口开启。按 Ctrl+C 退出。\n`);
 const args=process.platform==='darwin'?['open',[url]]:process.platform==='win32'?['cmd',['/c','start','',url]]:['xdg-open',[url]];
 const child=spawn(...args,{detached:true,stdio:'ignore'});child.on('error',()=>{});child.unref();
});
server.listen(port,'127.0.0.1');
