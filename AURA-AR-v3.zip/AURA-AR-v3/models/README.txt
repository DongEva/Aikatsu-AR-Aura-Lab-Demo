人体模型没有预置在此测试包中。
自动模式按需从官方模型地址读取 pose_landmarker_lite.task。
可在项目根目录运行 python3 cache_dependencies.py，成功后可用本地文件。
