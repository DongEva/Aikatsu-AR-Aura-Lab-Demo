@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 start.py
  goto end
)
where python >nul 2>nul
if not errorlevel 1 (
  python start.py
  goto end
)
where node >nul 2>nul
if not errorlevel 1 (
  node start.mjs
  goto end
)
echo 未找到 Python 3 或 Node.js。请先双击 index.html 使用演示模式。
:end
pause
