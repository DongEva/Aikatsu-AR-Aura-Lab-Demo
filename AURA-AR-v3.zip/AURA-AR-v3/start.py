#!/usr/bin/env python3
"""Serve AURA on loopback only. Standard library; no pip/npm dependencies."""
from __future__ import annotations
import argparse
import functools
import http.server
import pathlib
import socket
import threading
import webbrowser

ROOT = pathlib.Path(__file__).resolve().parent
class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.mjs': 'text/javascript', '.js': 'text/javascript',
                      '.wasm': 'application/wasm', '.task': 'application/octet-stream'}
    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Permissions-Policy', 'camera=(self), microphone=()')
        super().end_headers()
    def log_message(self, fmt, *args):
        if args and str(args[1] if len(args)>1 else '').startswith(('4','5')):
            super().log_message(fmt, *args)

def main() -> None:
    parser = argparse.ArgumentParser(description='Start the local AURA AR playground.')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if not 1024 <= args.port <= 65499:
        parser.error('Port must be between 1024 and 65499.')
    handler = functools.partial(Handler, directory=str(ROOT))
    server = None
    for port in range(args.port, args.port + 20):
        try:
            server = http.server.ThreadingHTTPServer(('127.0.0.1', port), handler)
            break
        except OSError as exc:
            if port == args.port + 19:
                raise SystemExit(f'No available local port: {exc}') from exc
    assert server is not None
    url = f'http://127.0.0.1:{server.server_port}/'
    print('\n  AURA / 偶像气场实验室\n')
    print(f'  浏览器地址 / Open in browser: {url}')
    print('  推荐使用 Chrome。演示无需网络；自动跟踪首次需要联网。')
    print('  保持这个终端窗口开启。按 Ctrl+C 退出。\n')
    if not args.no_browser:
        timer = threading.Timer(0.6, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        print('\nAURA stopped.')
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
