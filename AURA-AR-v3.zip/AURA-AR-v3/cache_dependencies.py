#!/usr/bin/env python3
"""Optional: download pinned MediaPipe runtime/model for offline localhost use.

Not required for the demo or for manual camera positioning.
Only downloads executable runtime from the named official-package CDNs.
Does not collect camera images, accounts or credentials.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
from pathlib import Path
import json
import time
import urllib.error
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parent
VERSION='0.10.21'
CDNS=[f'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@{VERSION}',
      f'https://unpkg.com/@mediapipe/tasks-vision@{VERSION}']
MODEL='https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task'
FILES={
 'vendor/vision_bundle.mjs':[f'{u}/vision_bundle.mjs' for u in CDNS],
 **{f'vendor/wasm/{name}':[f'{u}/wasm/{name}' for u in CDNS] for name in [
  'vision_wasm_internal.js','vision_wasm_internal.wasm',
  'vision_wasm_nosimd_internal.js','vision_wasm_nosimd_internal.wasm']},
 'models/pose_landmarker_lite.task':[MODEL],
}
def valid(path: Path) -> bool:
    if not path.exists() or path.stat().st_size<1000: return False
    with path.open('rb') as f: head=f.read(128)
    if path.suffix=='.wasm': return head.startswith(b'\x00asm')
    if path.suffix=='.task': return zipfile.is_zipfile(path)
    return not head.lstrip().lower().startswith((b'<!doctype',b'<html'))

def fetch(item):
    name,urls=item
    dest=ROOT/name
    if valid(dest):
        data=dest.read_bytes()
        return name,{'bytes':len(data),'sha256':sha256(data).hexdigest(),'status':'already present'}
    dest.parent.mkdir(parents=True,exist_ok=True)
    errors=[]
    for url in urls:
        for attempt in range(2):
            try:
                req=urllib.request.Request(url,headers={'User-Agent':'AURA-Local-Asset-Setup/1.0'})
                with urllib.request.urlopen(req,timeout=90) as response:
                    data=response.read()
                # Temporary file retains its real extension for validation.
                temp=dest.with_name('.download-'+dest.name)
                temp.write_bytes(data)
                if not valid(temp):
                    temp.unlink(missing_ok=True)
                    raise ValueError('The response was not a valid runtime/model file.')
                temp.replace(dest)
                return name,{'bytes':len(data),'sha256':sha256(data).hexdigest(),'source':url,'status':'downloaded'}
            except (OSError,ValueError,urllib.error.URLError) as exc:
                errors.append(str(exc));time.sleep(.5)
    raise RuntimeError(f'{name}: '+ '; '.join(errors[-2:]))

def main():
    print('AURA — 缓存自动人体跟踪组件（需要联网）')
    print('只下载程序和模型，不访问摄像头。完成后仍需使用 localhost 启动。\n')
    manifest={'mediapipe_version':VERSION,'files':{}}
    errors=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        jobs=[pool.submit(fetch,item) for item in FILES.items()]
        for job in as_completed(jobs):
            try:
                name,info=job.result();manifest['files'][name]=info
                print(f"  OK  {name} ({info['bytes']/1024/1024:.1f} MB)")
            except Exception as exc:
                errors.append(str(exc));print(f'  ERROR {exc}')
    (ROOT/'offline_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    if errors:
        print('\n部分下载失败。检查网络后重试；已成功的文件会跳过。演示和手动模式仍然可用。')
        raise SystemExit(1)
    print('\n缓存完成。运行 Start.command / Start.bat，或 python3 start.py。')
    print('现在网页会优先从本地读取模型和运行库。')
if __name__=='__main__':
    main()
